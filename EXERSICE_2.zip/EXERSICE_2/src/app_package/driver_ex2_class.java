package app_package;

public class driver_ex2_class {

	public static void main(String[] args) {
		MyFrame f=new MyFrame();

	}

}
