package app_package;

public class student {
    private String name,lastname;
    private int id;
    public void set_name(String n) {this.name=n;}
    public void setlastname(String ln) {this.lastname=ln;}
    public void setid(int i) {this.id=i;}
    public String getname() {return this.name;}
    public String getlastname() {return this.lastname;}
    public int getid() {return this.id;}
}
