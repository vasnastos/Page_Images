package app_package;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class start_ex3_class {

	public static void main(String[] args) {
	  String filename="salaries.txt";
	  FileReader fr=null;
	  try {
		  fr=new FileReader(filename);
		  Scanner sc=new Scanner(fr);
		  double avg=0.0;
		  int lower500=0;
		  int maxpos=-1;
		  double max=-1;
		  int i=0;
		  int cntover2000=0;
		  while(sc.hasNextLine())
		  {
			  String line=sc.nextLine();
			  if(line.startsWith("#")) continue;
			  double number=Double.parseDouble(line);
			  if(i==0)
			  {
				  max=number;
				  maxpos=0;
			  }
			  else
			  {
				  if(number>max)
				  {
					  max=number;
					  maxpos=i;
				  }
			  }
			  if(number<500)
			  {
				  lower500++;
			  }
			  if(number>2000.0)
			  {
				  avg+=number;
				  cntover2000++;
			  }
			  i++;
		  }
		  sc.close();
		  avg/=cntover2000;
		  String message="<html><body>";
		  message+="<h2 style=text-align:center; color:blue;>File OverView</h3>";
		  message+="<ul>";
		  message+="<li>Total number of employees with salary lower than 500:"+String.valueOf(lower500)+"</li>";
		  message+="<li>Average Salary of Employees with salary over 2000:"+String.valueOf(avg)+"</li>";
		  message+="<li>Highest paid Employee:"+String.valueOf(maxpos+1)+"</li>";
		  message+="</ul></body><html>";
		  JOptionPane.showMessageDialog(null, message);
	  }
        catch(FileNotFoundException fnd)
	  {
        	JOptionPane.showMessageDialog(null,"File did not found");
	  }

  }
}
